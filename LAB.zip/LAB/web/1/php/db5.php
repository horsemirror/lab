<!-- PHP program to delete the selected fields from the database CLASSROOM -->
<?php
$servername="localhost";
$username="root";
$password="";
$conn=mysqli_connect($servername,$username,$password);
if(!$conn)
{
echo ("Connection failed".mysqli_connect_error());
}
$sql="CREATE DATABASE IF NOT EXISTS classroom";
if(mysqli_query($conn,$sql))
{
echo "Database created successfully<br>";
}
else
{
echo "Error creating database".mysqli_error($conn);
}
mysqli_select_db($conn,"classroom");
$sql="CREATE TABLE IF NOT EXISTS s4bca
(ID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
NAME VARCHAR(15) NOT NULL,email VARCHAR(15) NOT NULL,mobile INT(15)
NOT NULL)";
if(mysqli_query($conn,$sql))
{
    echo "Table created successfully<br>";
    }
    else
    {
    echo "Error creating table".mysqli_error($conn);
    }
    ?>
    <html>
    <form method='post'>
    <h4>DELETE DATA FROM DB</h4>
    Enter Id to Delete <input type='text' name='did'>
    <input type='submit' value='DELETE' name='delete'></br>
    </br></br>
    </html>
    <?php
    function show()
    {
    echo "<table
    border='1'><tr><th>Id</th><th>Name</th><th>email</th><th>mobile</th></tr>";
    $sql="SELECT * FROM s4bca";
    global $conn;
    $rs=mysqli_query($conn,$sql);
     while($row=mysqli_fetch_array($rs))
    {
    echo "<tr><th>" .$row['ID']."</th><th>". $row['NAME']."</th><th>".
    $row['email']."</th><th>". $row['mobile']."</th></tr>";
}
}
if(isset($_POST['delete']))
{
$id=$_POST['did'];
$sql="DELETE FROM s4bca where ID=$id";
if(mysqli_query($conn,$sql))
{
 echo "Record of ID: ".$id." Successfully Deleted";
show();
}
else
{
 echo "</br>Error in Deletion" .mysqli_error($conn);
}
}
?>