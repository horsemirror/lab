<!-- a PHP program to create connection,creating database and table creation. -->
<?php
$servername="localhost";
$username="root";
$password="";
$conn=mysqli_connect($servername,$username,$password);
if(!$conn)
{
die("Connection failed: ".mysqli_connect_error());
}
$sql="CREATE DATABASE classroom";
if(mysqli_query($conn,$sql))
{
echo "<br>Database created successfully";
}
else
{
echo "Error creating database:".mysqli_error($conn);
}
mysqli_select_db($conn,"classroom");
$sql="CREATE TABLE s4bca(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(30) NOT NULL,
email VARCHAR(50) NOT NULL,
phone INT(10) NOT NULL
)";
if(mysqli_query($conn,$sql))
{
echo "<br>Table s4bca created successfully";
}
else
{
echo "Error creating table: ".mysqli_error($conn);
}
?>