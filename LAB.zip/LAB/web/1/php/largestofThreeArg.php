<!-- PHP program using function to find the largest of three numbers giving
the values passed as arguments. -->
<?php
function largest($a,$b,$c)
{
if($a>$b && $a>$c)
return $a;
else if($b>$a && $b>$c)
return $b;
else
return $c;
}
print("largest is".largest(22,48,90));
?>