<!-- a php program to select the data from the database CLASSROOM and
write it into the web browser. -->

<?php
$servername="localhost";
$username="root";
$password="";
$conn=mysqli_connect($servername,$username,$password);
if(!$conn)
{
die("Connection failed: ".mysqli_connect_error());
}
$sql="CREATE DATABASE classroom";
if(mysqli_query($conn,$sql))
{
echo "Database created successfully";
}
else
{
echo "Error creating database:".mysqli_error($conn);
}
mysqli_select_db($conn,"classroom");
$sql="CREATE TABLE s4bca(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(30) NOT NULL,
email VARCHAR(50) NOT NULL,
phone INT(10) NOT NULL
)";
if(mysqli_query($conn,$sql))
{
echo "Table s4bca created successfully";
}
else
{
echo "Error creating table: ".mysqli_error($conn);
}
if (isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['no'];
$sql="INSERT INTO s4bca (name,email,phone) VALUES ('$name','$email','$phone')";
if(mysqli_query($conn,$sql))
{
echo "<br> New record inserted successfully";
}
else
{
echo "Error".$sql.mysqli_error($conn);
}
}
echo "<table border='1'><tr><th>id</th><th>Name</th><th>email</th><th>phone
number</th></tr>";
$sql="SELECT * FROM s4bca";
$rs=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($rs))
{
echo"<tr><th>".$row['id']."</th><th>".$row['name']."</th><th>".$row['email']."</th><th>".
$row['phone']."</th><tr>";
}
?>
<html>
<form method='post'>
<br>
Enter name<input type='text' name='name'></br></br>
Enter Email<input type='text' name='email'></br></br>
Enter mobile<input type='text' name='no'></br></br>
<input type='submit' value='submit' name='submit'></br></br>
</form>
</html>