<!-- PHP program using for loop to find the prime numbers within a limit. -->
<?php
$limit=50;
for($i=1;$i<=$limit;$i++)
{
$f=0;
for($j=2;$j<=$i/2;$j++)
{
if($i % $j ==0)
{
$f=1;
}
}
if ($f==0)
 {
echo " ",$i;
}
}
?>