<!-- program to find the largest of three numbers. -->
<?php
$a=10;
$b=15;
$c=20;
if($a > $b && $a > $c)
{
echo "The largest is ",$a;
}
else if($b > $a && $b> $c)
{
echo "The largest is ",$b;
}
else
{
echo "The largest is ",$c;
}
?>