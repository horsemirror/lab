<!-- PHP program to find the largest of two numbers. -->
<?php
$a=10;
$b=15;
if($a > $b)
{
echo "The largest is ",$a;
}
else
{
echo "The largest is ",$b;
}
?>