<!-- PHP program to Create a database CLASSROOM and insert data into
the table S4BCA using html forms with attributes id,name,mail and phone -->
<?php
$servername="localhost";
$username="root";
$password="";
$conn=mysqli_connect($servername,$username,$password);
if(!$conn)
{
die("Connection failed: ".mysqli_connect_error());
}
$sql="CREATE DATABASE classroom";
if(mysqli_query($conn,$sql))
{
echo "Database created successfully";
}
else
{
echo "Error creating database:".mysqli_error($conn);
}
mysqli_select_db($conn,"classroom");
$sql="CREATE TABLE s4bca(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(30) NOT NULL,
email VARCHAR(50) NOT NULL,
phone INT(10) NOT NULL
)";
if(mysqli_query($conn,$sql))
{
echo "Table s4bca created successfully";
}
else
{
echo "Error creating table: ".mysqli_error($conn);
}
if (isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['no'];
$sql="INSERT INTO s4bca (name,email,phone) VALUES ('$name','$email','$phone')";
if(mysqli_query($conn,$sql))
{
echo "<br> New record inserted successfully";
}
else
{
echo "Error".$sql.mysqli_error($conn);
}
}
?>

<html>
<form method='post'>
Enter name<input type='text' name='name'></br></br>
Enter Email<input type='text' name='email'></br></br>
Enter mobile<input type='text' name='no'></br></br>
<input type='submit' value='submit' name='submit'></br></br>
</form>
</html>