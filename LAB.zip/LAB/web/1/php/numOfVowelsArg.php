<!-- PHP program to find the number of vowels in a string with the value of
string as arguments. -->
<?php
function vowel($string)
{
$count=0;
$i=0;
while($i <strlen($string))
{
if($string[$i]=='a' || $string[$i]=='e' || $string[$i]=='i' || $string[$i]=='o' || $string[$i]=='u' )
$count=$count+1;
$i++;
}
return $count;
}
$string="welcome";
print "number of vowels is ".vowel($string);
?>