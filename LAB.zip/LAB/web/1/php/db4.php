<!-- php program to update the selected fields from the database
CLASSROOM -->

<?php
$servername="localhost";
$username="root";
$password="";
$conn=mysqli_connect($servername,$username,$password);
if(!$conn)
{
echo ("Connection failed".mysqli_connect_error());
}
$sql="CREATE DATABASE IF NOT EXISTS classroom";
if(mysqli_query($conn,$sql))
{
echo "Database created successfully<br>";
}
mysqli_select_db($conn,"classroom");
$sql="CREATE TABLE IF NOT EXISTS s4bca
(ID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
NAME VARCHAR(15) NOT NULL,email VARCHAR(15) NOT NULL,mobile INT(15)
NOT NULL)";
if(mysqli_query($conn,$sql))
{
echo "Table created successfully<br>";
}
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['no'];
$sql="INSERT INTO s4bca (NAME,email,mobile)VALUES('$name','$email','$mobile')";
if(mysqli_query($conn,$sql))
{
echo "<br>New record inserted successfully<br><br>";
}
else
{
echo "Error".sql.mysqli_error($conn);
}
}
echo "<table
border='1'><tr><th>Id</th><th>Name</th><th>email</th><th>MOBILE</th></tr>";
$sql="SELECT * FROM s4bca";
$rs=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($rs))
{
echo "<tr><th>" .$row['ID']."</th><th>". $row['NAME']."</th><th>".
$row['email']."</th><th>". $row['mobile']."</th></tr>";
}
if(isset($_POST['view']))
{
    $id=$_POST['vid'];
    $sql="SELECT * FROM s4bca where ID=$id";
    if(!$id=="")
    {
    $rs=mysqli_query($conn,$sql);
    while($row=mysqli_fetch_array($rs))
    {
     $id=$row['ID'];
     $name=$row['NAME'];
     $email=$row['email'];
     $mobile=$row['mobile'];
     echo "<form method='post'><input type='hidden' name='uid' value=$id></br>";
     echo "<br><br>Name<input type='text' name='sname' value=$name><br></br>";
     echo "email<input type='text' name='semail' value=$email><br></br>";
     echo "mobile<input type='text' name='smobile' value=$mobile><br></br>";
     echo"<input type='submit' value='Update' name='update'><br></br></form>";
    }
    }
    }
    if(isset($_POST['update']))
    {
    $uid=$_POST['uid'];
    $Uname=$_POST['sname'];
    $email=$_POST['semail'];
    $mobile=$_POST['smobile'];
    $sql="UPDATE s4bca SET NAME='$Uname',email='$email',mobile='$mobile' WHERE ID
='$uid'";
if(mysqli_query($conn,$sql))
{
echo "</br>Updated<br>";
}
else
{
echo "</br>Error in In updating:" .mysqli_error($conn);
}
}
?>
<html>
<form method='post'>
Enter Name <input type='text' name='name'></br></br>
Enter Email <input type='text' name='email'></br></br>
Enter mobile <input type='text' name='no'></br></br>
<input type='submit' value='SUBMIT' name='submit'><br>
Enter Id to View<input type='text' name='vid'>
<input type='submit' value='VIEW & UPDATE' name='view'></br></br>
</br></br>
</html>