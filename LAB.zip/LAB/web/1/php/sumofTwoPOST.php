<!-- e PHP program to find the addition of two numbers using POST method -->
<html>
<head>
<form name='f1' action='addtn1.php' method='post'>
enter 1s<input type='text' name=n1><br><br>
enter 2nd<input type='text' name=n2><br><br>
<input type='submit' name='submit' value='submit'>
</head>
</html>
addtn1.php
<?php
$n1=$_POST['n1'];
$n2=$_POST['n2'];
echo "Sum is".($n1+$n2);
?>