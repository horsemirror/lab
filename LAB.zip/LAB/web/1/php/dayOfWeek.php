<!-- program using switch to find the day of the week. -->
<?php
$week=1;
switch($week)
{
case 1:
echo "the day is Sunday";
break;
case 2:
echo "the day Monday";
break;
case 3:
echo "the day is Tuesday";
break;
case 4:
echo "the day is Wednesday";
break;
case 5:
echo "the day is Thursday";
break;
case 6:
    echo "the day is Friday";
    break;
    case7:
    echo "the day is Saturday";
    break;
    default:
    echo "invalid entry";
    }
    ?>