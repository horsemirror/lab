<!-- PHP program to find the addition of two numbers using GET method. -->
<html>
<body>
<form>
enter first number:
<input type="number" name="number1" /><br><br>
enter second number:
<input type="number" name="number2" /><br><br>
<input type="submit" name="submit" value="Add">
</form>
</body>
<?php
$number1=$_GET['number1'];
$number2=$_GET['number2'];
echo "sum of $number1 and $number2 is: ".($number1 + $number2);
?>