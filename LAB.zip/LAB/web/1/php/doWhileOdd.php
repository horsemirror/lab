<!-- PHP program using do-while to find the odd numbers within a limit. -->
<?php
$i=1;
$limit=25;
do
{
echo "\n",$i;
$i=$i+2;
}while($i<=$limit);
?>