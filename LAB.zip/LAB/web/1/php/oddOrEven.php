<!-- PHP program using while to find the odd numbers within a limit -->
<?php
$i=1;
$limit=50;
while($i<=$limit)
{
echo "\n",$i;
$i=$i+2;
}
?>