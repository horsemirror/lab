<?php

echo "<h1>Welcome admin</h1>";

?>
