if cmp $1 $2; then
  echo "Same"
else
  echo "Different"
fi
