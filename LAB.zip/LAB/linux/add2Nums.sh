sum=$(( $1 + $2 ))
echo "Sum = $sum"
